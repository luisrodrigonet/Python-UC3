from django.urls import path
from . import views

app_name = "produtos"  # Namespace obrigatório para evitar conflitos

urlpatterns = [
    # CATEGORIAS
    path(
        "categorias/",
        views.CategoriaListView.as_view(),
        name="categoria_list",
    ),
    path(
        "categorias/<int:pk>/",
        views.CategoriaDetailView.as_view(),
        name="categoria_detail",
    ),
    # PRODUTOS
    path(
        "",
        views.ProdutoListView.as_view(),
        name="produto_list",
    ),
    path(
        "produtos/<int:pk>/",
        views.ProdutoDetailView.as_view(),
        name="produto_detail",
    ),
    # CLIENTES (apenas admin logado)
    path(
        "clientes/",
        views.ClienteListView.as_view(),
        name="cliente_list",
    ),
    path(
        "clientes/<int:pk>/",
        views.ClienteDetailView.as_view(),
        name="cliente_detail",
    ),
    # PEDIDOS (apenas usuário logado)
    # path('pedidos/', views.PedidoListView.as_view(), name='pedido_list'),
    # path('pedidos/<int:pk>/', views.PedidoDetailView.as_view(),
    #     name='pedido_detail'),
]
