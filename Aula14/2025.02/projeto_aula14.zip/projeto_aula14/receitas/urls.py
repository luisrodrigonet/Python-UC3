# paginas/urls.py
from django.urls import path

# Aula 09
from . import views

# Aula 09 - Define o namespace da aplicação (útil para referências em templates)
app_name = "receitas"

# Aula 09
urlpatterns = [
    # Rota de listagem de todas as receitas
    path("", views.lista_receitas, name="lista_receitas"),
    # Rota Dinâmica: <int:pk> captura um número inteiro e o passa como argumento 'pk' para a view.
    path("receita/<int:pk>/", views.detalhe_receita, name="detalhe_receita"),
]
