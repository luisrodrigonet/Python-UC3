# blog/views.py
from django.views.generic import ListView, DetailView
from django.shortcuts import get_object_or_404, redirect

# Controle de acesso
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required

# Models
from .models import Post, Categoria, Comentario

"""
CBV - Listar toodos os Posts "Publicados"
"""


class PostListView(ListView):
    model = Post
    template_name = "blog/post_list.html"  # Template que será usado
    context_object_name = "posts"  # Nome da variável no template
    ordering = ["-publicado_em"]  # Ordem dos posts do mais recente para o mais antigo

    def get_queryset(self):
        # Só retornar posts publicados
        return Post.objects.filter(status="publicado").order_by("-publicado_em")

    def get_context_data(self, **kwargs):
        # Adiciona categorias no contexto para sidebar
        context = super().get_context_data(**kwargs)
        context["categorias"] = Categoria.objects.all()
        return context


"""
CBV - Apresentar os detalhes de um Post específico
"""


class PostDetailView(DetailView):
    model = Post
    template_name = "blog/post_detail.html"
    context_object_name = "post"
    slug_field = "slug"  # Campo usado na URL
    slug_url_kwarg = "slug"  # Nome do parâmetro na URL

    def get_queryset(self):
        return Post.objects.filter(status="publicado")

    def get_context_data(self, **kwargs):
        # Adiciona comentários ao contexto
        context = super().get_context_data(**kwargs)
        post = self.get_object()
        context["comentarios"] = Comentario.objects.filter(post=post, ativo=True)
        return context


"""
FBV - Adicionar um comentário e um post
"""


@login_required
def adicionar_comentario(request, slug):
    """View para criar comentário, apenas para usuário autenticado."""
    post = get_object_or_404(Post, slug=slug, status="publicado")
    if request.method == "POST":
        conteudo = request.POST.get("conteudo")
        if conteudo:
            Comentario.objects.create(post=post, autor=request.user, conteudo=conteudo)
            return redirect("post_detail", slug=slug)
    return redirect("post_detail", slug=slug)
