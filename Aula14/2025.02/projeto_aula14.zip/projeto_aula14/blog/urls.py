# blog/urls.py
from django.urls import path

# Views
from .views import PostListView, PostDetailView, adicionar_comentario

app_name = "blog"

urlpatterns = [
    # Página inicial - lista de posts
    path("", PostListView.as_view(), name="post_list"),
    # Detalhes do post pelo slug
    path("post/<slug:slug>/", PostDetailView.as_view(), name="post_detail"),
    # Rota para criar comentário
    path(
        "post/<slug:slug>/comentario/",
        adicionar_comentario,
        name="adicionar_comentario",
    ),
]
