from django.contrib import admin

# Aula 08 - Adicionada a função include
from django.urls import path, include

# Aula 08
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Aula 11 - Aplica
    path("admin/", admin.site.urls),
    # Aula 08
    # Conecta todas as URLs da aplicação 'paginas' na raiz do site
    path("paginas/", include("paginas.urls")),
    # Aula 09 - Conecta todas as URLs definidas em 'receitas.urls' ao caminho base ('')
    path("receitas/", include("receitas.urls")),
    # Aula 10
    path("blog/", include("blog.urls")),
]


# Aula 08 - Apenas em modo de desenvolvimento (DEBUG=True)
if settings.DEBUG:
    # Configuração para servir Static Files
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    # Configuração para servir Media Files (arquivos de usuário)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
