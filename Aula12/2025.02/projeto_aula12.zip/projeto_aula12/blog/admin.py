# blog/admin.py
from django.contrib import admin

# Models
from .models import (
    Categoria,
    Post,
    Comentario,
)  # <-- importe as classes criadas no model


# FASE 1
# - Registro simples
# - apenas adiciona o model ao admin
# admin.site.register(Categoria)
# admin.site.register(Post)
# admin.site.register(Comentario)


# FASE 2
@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("nome", "slug")


##
# POST
##


""" 
class ComentarioInline(admin.TabularInline):
    model = Comentario
    extra = 2  # Número de formulários vazios extras a exibir
    fields = ("autor", "conteudo", "ativo")
    readonly_fields = ("criado_em", "atualizado_em")
    can_delete = True 
"""


class ComentarioInline(admin.StackedInline):
    model = Comentario
    extra = 0
    readonly_fields = ("criado_em", "atualizado_em")
    fieldsets = (
        ("Informações", {"fields": ("autor", "conteudo")}),
        (
            "Controle",
            {
                "fields": ("ativo", "criado_em", "atualizado_em"),
                "classes": ("collapse",),
            },
        ),
    )


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = (
        "titulo",
        "autor",
        "categoria",
        "status",
    )

    # Fase 03
    list_filter = (
        "status",
        "categoria",
        "criado_em",
        "publicado_em",
    )

    # Fase 04
    search_fields = (
        "titulo",
        "slug",
        "conteudo",
        "autor__username",
    )

    # Fase 05
    """ fields = (
        "titulo",
        "slug",
        "autor",
        "categoria",
        "status",
        "resumo",
        "conteudo",
        "imagem_destaque",
        "publicado_em",
        "visualizacoes",
    ) """

    # Fase 06
    readonly_fields = (
        # "slug",
        "criado_em",
        "atualizado_em",
    )

    # Fase 07
    fieldsets = (
        (
            "Informações Básicas",
            {"fields": ("titulo", "slug", "autor", "categoria")},
        ),
        (
            "Conteúdo",
            {"fields": ("conteudo", "resumo", "imagem_destaque"), "classes": ("wide",)},
        ),
        (
            "Publicação",
            {
                "fields": ("status", "publicado_em"),
                "description": "Defina o status e a data de publicação",
            },
        ),
        (
            "Estatísticas",
            {
                "fields": ("visualizacoes", "criado_em", "atualizado_em"),
                "classes": ("collapse",),
            },
        ),
    )

    # Fase 08
    prepopulated_fields = {"slug": ("titulo",)}

    # Fase 09
    date_hierarchy = "publicado_em"

    # Fase 10
    ordering = ["-publicado_em", "titulo"]

    # Fase 11
    list_per_page = 25  # Padrão é 100

    # Fase 12
    inlines = [ComentarioInline]


@admin.register(Comentario)
class ComentarioAdmin(admin.ModelAdmin):
    list_display = (
        "post",
        "autor",
        "conteudo",
    )
