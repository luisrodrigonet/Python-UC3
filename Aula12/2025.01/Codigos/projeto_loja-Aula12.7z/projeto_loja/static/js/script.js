// script.js - Aula 10
console.log("Seu JavaScript personalizado está funcionando!");