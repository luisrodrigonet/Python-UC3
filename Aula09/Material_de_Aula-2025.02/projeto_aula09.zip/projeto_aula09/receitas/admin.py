# 1. Importamos o módulo admin.
from django.contrib import admin

# 2. Importamos as classes de modelo que queremos registrar.
from .models import Categoria, Receita

# Registro simples do modelo Categoria
admin.site.register(Categoria)

# Registro simples do modelo Receita
admin.site.register(Receita)
