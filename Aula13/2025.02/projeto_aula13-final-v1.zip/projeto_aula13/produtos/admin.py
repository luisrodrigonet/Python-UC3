from django.contrib import admin

from .models import (
    Categoria,
    Produto,
    Cliente,
    Pedido,
    ItemPedido,
    ComentarioAvaliacao,
    EnderecoEntrega,
)


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("id", "nome", "descricao")  # Colunas exibidas na lista
    search_fields = ("nome",)  # Campo de busca


@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display = ("id", "nome", "preco", "estoque", "categoria")
    list_filter = ("categoria",)  # Filtro lateral para categoria
    search_fields = ("nome", "descricao")


# Criado na aula 12
# @admin.register(Cliente)
# class ClienteAdmin(admin.ModelAdmin):
#     list_display = ("id", "nome_completo", "email", "data_cadastro")
#     search_fields = ("nome_completo", "email")
#     list_filter = ("data_cadastro",)


# Modificado na aula 13
@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ("user", "nome_social", "telefone", "cpf", "sexo", "data_cadastro")
    list_filter = ("sexo", "data_cadastro")
    search_fields = (
        "user__username",
        "user__first_name",
        "user__last_name",
        "nome_social",
        "cpf",
    )
    ordering = ("-data_cadastro",)


@admin.register(EnderecoEntrega)
class EnderecoEntregaAdmin(admin.ModelAdmin):
    list_display = ("id", "cliente", "endereco", "cidade", "estado", "cep")
    search_fields = ("endereco", "cidade", "estado", "cep")


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ("id", "cliente", "endereco_entrega", "data_pedido", "status")
    list_filter = ("status", "data_pedido")
    search_fields = ("cliente__nome_completo",)
    date_hierarchy = "data_pedido"


@admin.register(ItemPedido)
class ItemPedidoAdmin(admin.ModelAdmin):
    list_display = ("id", "pedido", "produto", "quantidade", "preco_unitario")
    search_fields = ("produto__nome",)


@admin.register(ComentarioAvaliacao)
class ComentarioComentarioAvaliacao(admin.ModelAdmin):
    list_display = ("id", "produto", "cliente", "avaliacao", "data")
    list_filter = ("avaliacao", "data")
    search_fields = ("produto__nome", "cliente__nome_completo")
    date_hierarchy = "data"
