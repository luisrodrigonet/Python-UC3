from django.db import models

# aula 09
from django.contrib.auth.models import User


# aula 09
class Categoria(models.Model):
    """Modelo para as categorias das receitas (Ex: Sobremesa, Jantar)."""

    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome


# aula 09
class Receita(models.Model):
    """Modelo principal para as receitas."""

    # Campo para a chave primária que será usada na URL
    # O Django já cria um campo 'id' automaticamente, mas o usaremos implicitamente

    titulo = models.CharField(max_length=200)
    ingredientes = models.TextField()
    modo_preparo = models.TextField()
    tempo_preparo = models.IntegerField(help_text="Em minutos")
    data_publicacao = models.DateTimeField(auto_now_add=True)
    publicada = models.BooleanField(default=False)

    # Relação ManyToMany: Uma receita pode ter várias categorias e uma categoria pode ter várias receitas.
    categorias = models.ManyToManyField(Categoria, related_name="receitas")

    # Chave Estrangeira: Uma receita pertence a um único usuário/autor.
    autor = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.titulo  # Create your models here.
