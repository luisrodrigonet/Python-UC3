# blog/admin.py
from django.contrib import admin

# Models
from .models import (
    Categoria,
    Post,
    Comentario,
)  # <-- importe as classes criadas no model

# Registro simples - apenas adiciona o model ao admin
admin.site.register(Categoria)
admin.site.register(Post)
admin.site.register(Comentario)
