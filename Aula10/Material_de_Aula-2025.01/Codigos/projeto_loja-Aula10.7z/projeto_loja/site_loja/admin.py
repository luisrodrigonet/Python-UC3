# site_loja/admin.py - Aula 10

from django.contrib import admin
from .models import Perfil

admin.site.register(Perfil)