# blog/models.py
from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils.text import slugify


class Categoria(models.Model):
    """
    Model para representar categorias de posts.
    Um post pode pertencer a apenas uma categoria,
    mas uma categoria pode ter vários posts.
    """

    nome = models.CharField(
        max_length=100, unique=True, help_text="Nome único da categoria"
    )
    slug = models.SlugField(
        max_length=100,
        unique=True,
        blank=True,
        help_text="URL amigável para a categoria (gerado automaticamente)",
    )
    descricao = models.TextField(
        blank=True, help_text="Descrição detalhada da categoria"
    )
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"
        ordering = ["nome"]

    def __str__(self):
        """Retorna o nome da categoria quando convertida em string"""
        return self.nome

    def save(self, *args, **kwargs):
        """
        Sobrescreve o método save para gerar slug automaticamente
        se não for fornecido
        """
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        """Retorna a URL da categoria"""
        return reverse("posts_por_categoria", args=[self.slug])


class Post(models.Model):
    """
    Model para representar posts/artigos do blog.
    Cada post tem um autor (usuário), uma categoria,
    um título, conteúdo, e pode ter múltiplos comentários.
    """

    STATUS_CHOICES = (
        ("rascunho", "Rascunho"),
        ("publicado", "Publicado"),
    )

    titulo = models.CharField(
        max_length=200,
        help_text="Título do post (máximo 200 caracteres)",
    )

    slug = models.SlugField(
        max_length=200,
        unique=True,
        blank=True,
        help_text="URL amigável do post (gerado automaticamente)",
    )

    autor = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="posts",
        help_text="Autor do post (usuário do Django)",
    )
    categoria = models.ForeignKey(
        Categoria,
        on_delete=models.SET_NULL,
        null=True,
        related_name="posts",
        help_text="Categoria do post",
    )

    conteudo = models.TextField(
        help_text="Conteúdo completo do post (suporta HTML básico)"
    )

    resumo = models.TextField(
        max_length=300,
        blank=True,
        help_text="Resumo curto do post (exibido em cards)",
    )
    imagem_destaque = models.ImageField(
        upload_to="posts/%Y/%m/%d/",
        blank=True,
        help_text="Imagem de destaque do post",
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="rascunho",
        help_text="Status de publicação do post",
    )
    criado_em = models.DateTimeField(auto_now_add=True)

    atualizado_em = models.DateTimeField(auto_now=True)

    publicado_em = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Data de publicação (null = não publicado)",
    )
    visualizacoes = models.PositiveIntegerField(
        default=0,
        help_text="Contador de visualizações",
    )

    class Meta:
        verbose_name = "Post"
        verbose_name_plural = "Posts"
        ordering = ["-publicado_em", "-criado_em"]

    def __str__(self):
        """Retorna o título do post"""
        return self.titulo

    def save(self, *args, **kwargs):
        """
        Sobrescreve o método save para gerar slug automaticamente
        """
        if not self.slug:
            self.slug = slugify(self.titulo)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        """Retorna a URL do post (para usar em templates)"""
        return reverse("post_detail", args=[self.slug])


class Comentario(models.Model):
    """
    Model para representar comentários em posts.
    Cada comentário pertence a um post e é feito por um usuário.
    """

    post = models.ForeignKey(
        Post,
        on_delete=models.CASCADE,
        related_name="comentarios",
        help_text="Post ao qual o comentário pertence",
    )
    autor = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="comentarios",
        help_text="Autor do comentário",
    )
    conteudo = models.TextField(help_text="Conteúdo do comentário")

    criado_em = models.DateTimeField(auto_now_add=True)

    atualizado_em = models.DateTimeField(auto_now=True)

    ativo = models.BooleanField(
        default=True,
        help_text="Se falso, comentário não será exibido",
    )

    class Meta:
        verbose_name = "Comentário"
        verbose_name_plural = "Comentários"
        ordering = ["-criado_em"]

    def __str__(self):
        """Retorna uma descrição do comentário"""
        return f'Comentário de {self.autor.username} em "{self.post.titulo}"'
