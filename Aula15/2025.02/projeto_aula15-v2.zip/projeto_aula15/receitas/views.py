# Aula 09
from django.shortcuts import render, get_object_or_404

# Aula 09
from .models import Receita


# Aula 09
def lista_receitas(request):
    """View para listar todas as receitas publicadas."""
    receitas_publicadas = Receita.objects.filter(publicada=True).order_by(
        "-data_publicacao"
    )
    context = {"receitas": receitas_publicadas}
    return render(request, "receitas/lista.html", context)


# Aula 09
def detalhe_receita(request, pk):
    """
    View para exibir os detalhes de uma receita específica.

    :param request: O objeto HttpRequest.
    :param pk: A chave primária (ID) da receita, capturada da URL.
    """
    # 1. Busca no banco de dados:
    # get_object_or_404 busca o objeto pelo pk e, se não encontrar, lança um erro 404.
    receita = get_object_or_404(Receita, pk=pk, publicada=True)

    # 2. Criação do contexto:
    # O objeto 'receita' é empacotado em um dicionário para ser enviado ao template.
    context = {"receita": receita}

    # 3. Renderização:
    # O template 'detalhe.html' é renderizado com os dados da receita.
    return render(request, "receitas/detalhe.html", context)
