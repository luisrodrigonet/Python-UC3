from django.db import models
from django.contrib.auth.models import User


class Categoria(models.Model):
    nome = models.CharField(
        verbose_name="Categoria",
        help_text="Informe um nome para a categoria",
        max_length=100,
    )
    descricao = models.TextField(
        verbose_name="Descrição",
        help_text="Informe uma descrição para a categoria",
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.nome


class Produto(models.Model):
    nome = models.CharField(max_length=150)
    descricao = models.TextField()
    # Adicionado na aula 13
    foto = models.ImageField(upload_to="produtos/", blank=True, null=True)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    estoque = models.IntegerField()
    categoria = models.ForeignKey(
        Categoria, on_delete=models.CASCADE, related_name="produtos"
    )

    def __str__(self):
        return self.nome


##
# Criado na aula 12
# Modificado na aula 13
##
""" 
class Cliente(models.Model):
    nome_completo = models.CharField(max_length=200)
    email = models.EmailField(unique=True)
    data_cadastro = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nome_completo 
"""


class Cliente(models.Model):
    SEXO_CHOICES = [
        ("M", "Masculino"),
        ("F", "Feminino"),
        ("O", "Outro"),
        ("N", "Prefiro não dizer"),
    ]

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="cliente_perfil",
        null=True,
    )
    # nome_completo = models.CharField(max_length=200)
    data_cadastro = models.DateTimeField(auto_now_add=True)
    telefone = models.CharField(max_length=20, blank=True, null=True)
    foto = models.ImageField(upload_to="fotos_perfil/", blank=True, null=True)
    sexo = models.CharField(max_length=1, choices=SEXO_CHOICES, blank=True)
    nome_social = models.CharField(max_length=150, blank=True, null=True)
    data_nascimento = models.DateField(blank=True, null=True)
    cpf = models.CharField(
        max_length=14,
        unique=True,
        blank=True,
        null=True,
        help_text="Formato: 000.000.000-00",
    )

    def __str__(self):
        return self.nome_social if self.nome_social else self.user.get_full_name()


class EnderecoEntrega(models.Model):
    cliente = models.ForeignKey(
        Cliente, on_delete=models.CASCADE, related_name="enderecos"
    )
    endereco = models.CharField(max_length=255)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=100)
    cep = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.endereco}, {self.cidade} - {self.estado}, CEP: {self.cep}"


class Pedido(models.Model):
    STATUS_CHOICES = [
        ("P", "Pendente"),
        ("PA", "Pago"),
        ("E", "Enviado"),
    ]

    cliente = models.ForeignKey(
        Cliente, on_delete=models.CASCADE, related_name="pedidos"
    )
    endereco_entrega = models.ForeignKey(
        EnderecoEntrega, on_delete=models.PROTECT, related_name="pedidos"
    )
    data_pedido = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=2, choices=STATUS_CHOICES, default="P")

    def __str__(self):
        return f"Pedido {self.id} - {self.cliente.nome_completo}"

    def total_pedido(self):
        return sum(item.quantidade * item.preco_unitario for item in self.itens.all())


class ItemPedido(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name="itens")
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.IntegerField()
    preco_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.quantidade} x {self.produto.nome}"


class ComentarioAvaliacao(models.Model):
    produto = models.ForeignKey(
        Produto, on_delete=models.CASCADE, related_name="comentarios"
    )
    cliente = models.ForeignKey(
        Cliente, on_delete=models.CASCADE, related_name="comentarios"
    )
    comentario = models.TextField()
    avaliacao = models.IntegerField()  # deveria ter validação para 1 a 5
    data = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Avaliação {self.avaliacao} por {self.cliente.nome_completo} para {self.produto.nome}"


# @method_decorator(login_required, name='dispatch')
# class PedidoListView(LoginRequiredMixin, ListView):
#     """Lista de pedidos do cliente logado"""
#     model = Pedido
#     template_name = 'produtos/pedido_list.html'
#     context_object_name = 'pedidos'
#     login_url = '/accounts/login/'

#     def get_queryset(self):
#         """Filtra apenas pedidos do cliente logado"""
#         cliente = self.request.user.cliente_perfil
#         return cliente.pedidos.select_related('endereco_entrega__cliente').prefetch_related(
#             'itens__produto'
#         ).order_by('-data_pedido')


# class PedidoDetailView(LoginRequiredMixin, DetailView):
#     """Detalhes completos de um pedido"""
#     model = Pedido
#     template_name = 'produtos/pedido_detail.html'
#     context_object_name = 'pedido'
#     login_url = '/accounts/login/'

#     def get_queryset(self):
#         """Verifica se o usuário é dono do pedido"""
#         return Pedido.objects.select_related(
#             'cliente__user', 'endereco_entrega'
#         ).prefetch_related('itens__produto')

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context['total_pedido'] = self.object.total_pedido()
#         return context
