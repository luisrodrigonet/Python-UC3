from django.shortcuts import render

from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.contrib.auth.mixins import (
    LoginRequiredMixin,
    UserPassesTestMixin,
)

from django.urls import reverse_lazy

from .models import (
    Categoria,
    Produto,
    Cliente,
)


##============================================================================
# Classe - Categorias
##============================================================================


##
# Categoria - List - Versão Completa
##
# class CategoriaListView(ListView):
#     """Lista todas as categorias de produtos"""
#
#     model = Categoria
#     template_name = "produtos/categorias/categoria_list.html"
#     context_object_name = "categorias"
#     paginate_by = 10  # Paginação para melhor performance
#
#     def get_context_data(self, **kwargs):
#         """Adiciona contexto extra para o template"""
#         context = super().get_context_data(**kwargs)
#         context["total_categorias"] = Categoria.objects.count()
#         return context


##
# Categoria - List - Versão Simples
##
class CategoriaListView(ListView):
    model = Categoria
    template_name = "produtos/categorias/categoria_list_simples.html"
    context_object_name = "categorias"


##
# Categoria - Detail - Versão Completa
##
# class CategoriaDetailView(DetailView):
#     """Detalhes de uma categoria específica"""
#
#     model = Categoria
#     template_name = "produtos/categorias/categoria_detail.html"
#     context_object_name = "categoria"
#
#     def get_context_data(self, **kwargs):
#         """Inclui os produtos relacionados à categoria"""
#         context = super().get_context_data(**kwargs)
#         context["produtos"] = self.object.produtos.all()[:12]  # Primeiros 12 produtos
#         context["total_produtos"] = self.object.produtos.count()
#         return context


##
# Categoria - Detail - Versão Simples
##
class CategoriaDetailView(DetailView):
    model = Categoria
    template_name = "produtos/categorias/categoria_detail_simples.html"
    context_object_name = "categoria"


##============================================================================
# Classe - Produtos
##============================================================================

##
# Produtos - List - Versão Completa
##
# class ProdutoListView(ListView):
#     """Lista todos os produtos disponíveis"""
#
#     model = Produto
#     template_name = "produtos/produtos/produto_list.html"
#     context_object_name = "produtos"
#     paginate_by = 12  # Ideal para grid de produtos
#
#     def get_queryset(self):
#         """Filtra apenas produtos com estoque > 0 por padrão"""
#         return Produto.objects.filter(estoque__gt=0).select_related("categoria")
#
#     def get_context_data(self, **kwargs):
#         """Adiciona estatísticas e categorias para filtros"""
#         context = super().get_context_data(**kwargs)
#         context["categorias"] = Categoria.objects.all()
#         context["produtos_em_estoque"] = Produto.objects.filter(estoque__gt=0).count()
#         context["produtos_esgotados"] = Produto.objects.filter(estoque=0).count()
#         return context


##
# Produtos - List -  Versão Simples
##
class ProdutoListView(ListView):
    model = Produto
    template_name = "produtos/produtos/produto_list_simples.html"
    context_object_name = "produtos"


##
# Produtos - Detail - Versão Completa
##
# class ProdutoDetailView(DetailView):
#     """Página de detalhes do produto"""
#
#     model = Produto
#     template_name = "produtos/produtos/produto_detail.html"
#     context_object_name = "produto"
#
#     def get_queryset(self):
#         """Otimiza consultas com prefetch_related"""
#         return Produto.objects.select_related("categoria").prefetch_related(
#             "comentarios__cliente"
#         )
#
#     def get_context_data(self, **kwargs):
#         """Inclui comentários, avaliações e produto similar"""
#         context = super().get_context_data(**kwargs)
#         produto = self.object
#
#         # Média das avaliações
#         comentarios = produto.comentarios.all()
#         if comentarios.exists():
#             context["avaliacao_media"] = (
#                 sum(c.avaliacao for c in comentarios) / comentarios.count()
#             )
#             context["total_comentarios"] = comentarios.count()
#         else:
#             context["avaliacao_media"] = 0
#             context["total_comentarios"] = 0
#
#         # Produtos similares (mesma categoria)
#         context["produtos_similares"] = Produto.objects.filter(
#             categoria=produto.categoria
#         ).exclude(id=produto.id)[:4]
#
#         return context


##
# Produtos - Detail - Versão Simplificada
##
class ProdutoDetailView(DetailView):
    model = Produto
    template_name = "produtos/produtos/produto_detail_simples.html"
    context_object_name = "produto"


##
# Produtos - Create
##
class ProdutoCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Produto
    fields = ["nome", "descricao", "preco", "estoque", "categoria", "foto"]
    template_name = "produtos/produtos/produto_form.html"
    success_url = reverse_lazy("produtos:produto_list")

    def test_func(self):
        return self.request.user.is_staff

    def form_valid(self, form):
        form.instance.criado_por = self.request.user
        return super().form_valid(form)


##
# Produtos - Update
##
class ProdutoUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Produto
    fields = ["nome", "descricao", "preco", "estoque", "categoria", "foto"]
    template_name = "produtos/produtos/produto_form.html"
    success_url = reverse_lazy("produtos:produto_list")

    def test_func(self):
        return self.request.user.is_staff


##
# Produtos - Delete
##
class ProdutoDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Produto
    template_name = "produtos/produtos/produto_confirm_delete.html"
    success_url = reverse_lazy("produtos:produto_list")

    def test_func(self):
        return self.request.user.is_staff


##============================================================================
# Classe - Clientes
##============================================================================


##
# Clientes - List
##
class ClienteListView(LoginRequiredMixin, ListView):
    """Lista de todos os clientes (apenas para administradores)"""

    model = Cliente
    template_name = "produtos/clientes/cliente_list.html"
    context_object_name = "clientes"
    login_url = "/accounts/login/"

    def get_queryset(self):
        """Otimiza com select_related para o user"""
        return Cliente.objects.select_related("user").all()


##
# Clientes - Details - Simples
##
class ClienteDetailView(DetailView):
    model = Cliente
    template_name = "produtos/clientes/cliente_detail_basico.html"
    context_object_name = "cliente"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["enderecos"] = self.object.enderecos.all()
        return context


##
# Clientes - Details - Completo
##
# class ClienteDetailView(LoginRequiredMixin, DetailView):
#     """Perfil detalhado do cliente"""
#
#     model = Cliente
#     template_name = "produtos/clientes/cliente_detail.html"
#     context_object_name = "cliente"
#     login_url = "/accounts/login/"
#
#     def get_queryset(self):
#         """Otimiza todas as consultas relacionadas"""
#         return Cliente.objects.select_related("user").prefetch_related(
#             "enderecos", "pedidos__itens__produto", "comentarios__produto"
#         )
#
#     def get_context_data(self, **kwargs):
#         """Contexto completo do perfil do cliente"""
#         context = super().get_context_data(**kwargs)
#         cliente = self.object
#
#         # Estatísticas do cliente
#         context["total_pedidos"] = cliente.pedidos.count()
#         context["total_enderecos"] = cliente.enderecos.count()
#         context["total_comentarios"] = cliente.comentarios.count()
#
#         # Últimos pedidos
#         context["ultimos_pedidos"] = cliente.pedidos.all().order_by("-data_pedido")[:5]
#
#         # Endereços principais
#         context["enderecos"] = cliente.enderecos.all()
#
#         return context
