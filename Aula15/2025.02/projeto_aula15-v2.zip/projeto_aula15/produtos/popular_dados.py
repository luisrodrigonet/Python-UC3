#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para popular o banco de dados com categorias e produtos

Execute no Django shell:

python manage.py shell

Então:

#exec(open('popular_dados.py').read())
exec(open('produtos/popular_dados.py', encoding='utf-8').read())
"""

from django.db import transaction
from decimal import Decimal
from produtos.models import Categoria, Produto

# Dados das categorias (20 categorias)
categorias_data = [
    {
        "nome": "Tênis Esportivo",
        "descricao": "Tênis para corrida e atividades esportivas",
    },
    {"nome": "Tênis Casual", "descricao": "Tênis para uso diário e casual"},
    {
        "nome": "Botas de Trabalho",
        "descricao": "Botas resistentes para trabalho pesado",
    },
    {
        "nome": "Sapatos Sociais Masculino",
        "descricao": "Sapatos elegantes para eventos formais",
    },
    {
        "nome": "Sapatos Sociais Feminino",
        "descricao": "Sapatos de salto e elegantes para mulheres",
    },
    {"nome": "Sandálias Masculino", "descricao": "Sandálias confortáveis para homens"},
    {
        "nome": "Sandálias Feminino",
        "descricao": "Sandálias de diversas alturas para mulheres",
    },
    {"nome": "Chinelos", "descricao": "Chinelos para uso doméstico e praia"},
    {"nome": "Mocassins", "descricao": "Sapatos mocassins confortáveis e elegantes"},
    {"nome": "Tênis Running", "descricao": "Tênis especializados para corrida"},
    {"nome": "Tênis Basketball", "descricao": "Tênis para basquete e quadra"},
    {
        "nome": "Botas Trekking",
        "descricao": "Botas para trilhas e aventuras ao ar livre",
    },
    {"nome": "Sapatos Oxford", "descricao": "Sapatos oxford clássicos"},
    {"nome": "Sapatos Derby", "descricao": "Sapatos derby mais informais"},
    {"nome": "Salto Alto", "descricao": "Sapatos de salto alto para eventos especiais"},
    {"nome": "Salto Médio", "descricao": "Sapatos com salto médio para uso diário"},
    {"nome": "Rasteirinha", "descricao": "Rasteiras confortáveis para o dia a dia"},
    {"nome": "Tênis Minimalista", "descricao": "Tênis minimalistas e leves"},
    {"nome": "Botas Cano Alto", "descricao": "Botas de cano alto para inverno"},
    {"nome": "Botas Cano Baixo", "descricao": "Botas curtas para uso casual"},
]

# Dados dos produtos (30 produtos)
produtos_data = [
    # Tênis Esportivo
    {
        "nome": "Nike Air Zoom Pegasus 40",
        "preco": "699.90",
        "estoque": 25,
        "categoria": "Tênis Esportivo",
        "descricao": "Tênis de corrida com amortecimento Air Zoom",
    },
    {
        "nome": "Adidas Ultraboost 23",
        "preco": "899.90",
        "estoque": 18,
        "categoria": "Tênis Esportivo",
        "descricao": "Tênis com tecnologia Boost para máxima energia",
    },
    # Tênis Casual
    {
        "nome": "Vans Old Skool",
        "preco": "299.90",
        "estoque": 42,
        "categoria": "Tênis Casual",
        "descricao": "Clássico tênis skate da Vans",
    },
    {
        "nome": "Converse Chuck Taylor",
        "preco": "349.90",
        "estoque": 35,
        "categoria": "Tênis Casual",
        "descricao": "Ícone atemporal do streetwear",
    },
    # Botas de Trabalho
    {
        "nome": "Timberland PRO",
        "preco": "549.90",
        "estoque": 12,
        "categoria": "Botas de Trabalho",
        "descricao": "Bota de segurança com biqueira de aço",
    },
    {
        "nome": "Caterpillar Logger",
        "preco": "479.90",
        "estoque": 15,
        "categoria": "Botas de Trabalho",
        "descricao": "Bota resistente para construção",
    },
    # Sapatos Sociais
    {
        "nome": "Sapato Social Oxford Preto",
        "preco": "399.90",
        "estoque": 28,
        "categoria": "Sapatos Sociais Masculino",
        "descricao": "Oxford clássico em couro preto",
    },
    {
        "nome": "Sapato Derby Marrom",
        "preco": "429.90",
        "estoque": 22,
        "categoria": "Sapatos Sociais Masculino",
        "descricao": "Derby elegante em couro marrom",
    },
    # Sandálias
    {
        "nome": "Havaianas Top",
        "preco": "39.90",
        "estoque": 150,
        "categoria": "Chinelos",
        "descricao": "Clássico chinelo brasileiro",
    },
    {
        "nome": "Sandália Rider",
        "preco": "89.90",
        "estoque": 65,
        "categoria": "Sandálias Feminino",
        "descricao": "Sandália anatômica e confortável",
    },
    # Mais produtos...
    {
        "nome": "Nike Air Force 1",
        "preco": "599.90",
        "estoque": 20,
        "categoria": "Tênis Casual",
        "descricao": "Ícone do streetwear mundial",
    },
    {
        "nome": "Puma RS-X",
        "preco": "499.90",
        "estoque": 16,
        "categoria": "Tênis Esportivo",
        "descricao": "Tênis retrô esportivo",
    },
    {
        "nome": "Asics Gel-Kayano",
        "preco": "799.90",
        "estoque": 10,
        "categoria": "Tênis Running",
        "descricao": "Tênis de corrida com suporte premium",
    },
    {
        "nome": "New Balance 574",
        "preco": "449.90",
        "estoque": 30,
        "categoria": "Tênis Casual",
        "descricao": "Clássico lifestyle da New Balance",
    },
    {
        "nome": "Salto Alto Vermelho",
        "preco": "299.90",
        "estoque": 18,
        "categoria": "Salto Alto",
        "descricao": "Salto 10cm em verniz vermelho",
    },
    {
        "nome": "Bota Timberland Clássica",
        "preco": "699.90",
        "estoque": 14,
        "categoria": "Botas Cano Alto",
        "descricao": "Bota amarela clássica Timberland",
    },
    {
        "nome": "Mocassim Penny Loafer",
        "preco": "379.90",
        "estoque": 25,
        "categoria": "Mocassins",
        "descricao": "Mocassim clássico com pespontos",
    },
    {
        "nome": "Tênis Adidas Samba",
        "preco": "399.90",
        "estoque": 28,
        "categoria": "Tênis Casual",
        "descricao": "Clássico Samba da Adidas",
    },
    {
        "nome": "Botina de Couro Marrom",
        "preco": "289.90",
        "estoque": 32,
        "categoria": "Botas Cano Baixo",
        "descricao": "Botina casual em couro legítimo",
    },
    {
        "nome": "Rasteirinha Dourada",
        "preco": "129.90",
        "estoque": 45,
        "categoria": "Rasteirinha",
        "descricao": "Rasteira com detalhes metálicos",
    },
    {
        "nome": "Tênis Olympikus STK",
        "preco": "249.90",
        "estoque": 38,
        "categoria": "Tênis Running",
        "descricao": "Tênis nacional de corrida acessível",
    },
    {
        "nome": "Sapato Social Feminino",
        "preco": "349.90",
        "estoque": 20,
        "categoria": "Sapatos Sociais Feminino",
        "descricao": "Scarpin preto elegante",
    },
]


@transaction.atomic
def popular_banco():
    """Popula o banco com categorias e produtos"""

    print("🗑️ Limpando dados existentes...")
    Produto.objects.all().delete()
    Categoria.objects.all().delete()

    print("📁 Criando categorias...")
    categorias = {}
    for data in categorias_data:
        cat = Categoria.objects.create(nome=data["nome"], descricao=data["descricao"])
        categorias[data["nome"]] = cat
        print(f"   ✅ {cat.nome}")

    print("\n📦 Criando produtos...")
    for data in produtos_data:
        produto = Produto.objects.create(
            nome=data["nome"],
            descricao=data["descricao"],
            preco=Decimal(data["preco"]),
            estoque=data["estoque"],
            categoria=categorias[data["categoria"]],
        )
        print(f"   ✅ {produto.nome} - R$ {produto.preco} (Estoque: {produto.estoque})")

    print(f"\n🎉 Finalizado! Criadas:")
    print(f"   📂 {Categoria.objects.count()} categorias")
    print(f"   👟 {Produto.objects.count()} produtos")


# Executar o script
# if __name__ == "__main__":
#    popular_banco()

popular_banco()
